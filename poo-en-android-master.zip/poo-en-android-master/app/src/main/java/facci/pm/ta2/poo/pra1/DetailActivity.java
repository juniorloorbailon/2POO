package facci.pm.ta2.poo.pra1;

import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import facci.pm.ta2.poo.datalevel.DataException;
import facci.pm.ta2.poo.datalevel.DataObject;
import facci.pm.ta2.poo.datalevel.DataQuery;
import facci.pm.ta2.poo.datalevel.GetCallback;

public class DetailActivity extends AppCompatActivity {
TextView tvprecio;
    ImageView imagen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
tvprecio = (TextView) findViewById(R.id.tv_precio);

        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("PR1 :: Detail");


        // INICIO - CODE6

        imagen = findViewById(R.id.thumbnail);
        Intent intent = getIntent();
        Bitmap bitmap = intent.getParcelableExtra("img");

        imagen.setImageBitmap(bitmap);
        tvprecio = findViewById(R.id.pre);
        String a = getIntent().getExtras().getString("precio");
        tvprecio.setText(a);


        // FIN - CODE6

    }

}
